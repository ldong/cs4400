<?php
       /*
             connects to the person table via the following syntax
        */ 
        $dbc = mysql_connect('localhost', 'cs4400_Group17', 'Ve5NFbp_')
              or die('Could not connect: ' . mysql_error()); 

         mysql_select_db('cs4400_Group17'); 
         //echo 'Connected successfully';

         $ccode = $_POST["ccode"];
         $key = $_POST["key"]; 

echo "<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">\n"; 
echo "<head>\n"; 
echo "	<title>Student Personal Infomation form</title>\n"; 
echo "</head>\n"; 
echo "    <body>\n"; 
echo "     <form method=\"post\" action=\"findTutor.php\">    \n"; 
echo "	 <label for=\"ccode\">Course Code: </label>\n"; 
echo "	  <input type=\"text\" id=\"ccode\" name=\"ccode\" />\n"; 
echo "\n"; 
echo "	 <label for=\"key\"> Or  Key Word: </label>\n"; 
echo "	  <input type=\"text\" id=\"key\" name=\"key\" />\n"; 
echo "\n"; 
echo "       <input type=\"submit\" value=\"Search\" name=\"submit\"/>\n"; 
echo "\n"; 
echo "</form>\n"; 
echo "\n"; 

        $query = "SELECT * FROM Tutors_For ORDER BY "."Username";
        $result= mysql_query($query);
        $count = mysql_num_rows($result);
        $loop =  $count;
        //$arr = mysql_fetch_array($result);

        echo "<table border='1'><tr> ";
        echo "<th>Course Code</th> <th>Course Name</th> <th>Tutor Name</th> <th>Tutor Email</th>";
        echo "</tr>";

        while($row = mysql_fetch_array( $result )) {
		// Print out the contents of each row into a table
        	$coursetitle = $row['Title'];
            $query1 = "SELECT * FROM CCode ORDER BY Code where Title= 'coursetitle'";
            $result1= mysql_query("$query2");
        	while($row1 = mysql_fetch_array($result1))
        	{
        		echo "<tr><td>"; 
        		echo $row1['CCode'];
				echo "</td><td>"; 
				
				echo $row1['Title'];
				echo "</td><td>"; 

        		$tutorname = $row['Username'];
				echo $tutorname;
				echo "</td><td>";

		        $query2 = "SELECT Email_Id FROM Regular_User where Usename='$tutorname'";
		        $result2= mysql_query("$query2");
                $email=mysql_fetch_array($result2);
				echo $email;
				echo "</td><td>";

				echo "</td></tr>"; 
		    }	
		

		} 
		echo "</table>";




echo "\n"; 
echo "    </body>\n"; 
echo "</html>\n";
?>